import React from 'react';

function Footer() {
    return (
        <footer>
            <p>Sou o footer da pagina</p>
        </footer>
    );
}

export default Footer;