import React from 'react';

function Box({info}) {
    return (
        <div className='Box'>
            <p>{info}</p>
        </div>
    );
}

export default Box;