import React from 'react';

function Header() {
    return (
        <header>
            <p>Sou o header da página</p>
        </header>
    );
}

export default Header;